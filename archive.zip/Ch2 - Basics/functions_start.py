#
# Example file for working with functions
# LinkedIn Learning Python course by Joe Marini
#


# TODO: define a basic function


# TODO: function that takes arguments


# TODO: function that returns a value


# TODO: function with default value for an argument


# TODO: function with variable number of arguments


