# LinkedIn Learning Python course by Joe Marini
#


# TODO: import the math module, which contains features for working with mathematics


# TODO: the math module contains lots of pre-built functions


# TODO: in addition to functions, some modules contain useful constants 


# TODO: try some of the math functions for yourself here:
